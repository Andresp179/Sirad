<?php
session_start();

$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");


$contrasena= $_POST['contraseña'];
$nuevaconrasena= $_POST['nuevacontraseña'];
$confirme=$_POST['confirmecontraseña'];

$consult ="select * from usuario where contrasena ='".$contrasena."' and documento ='".$_SESSION['docuemnto']."'";
$resultado = mysql_query($consult,$conexion);
$total=  mysql_num_rows($resultado);
if($total >0){
 if($nuevacontrasena==confirme){
    $actualiza ="update usuario set contrasena='$confirme'";
    mysql_query($actualiza,$conexion);
     
     
 }
    
    
    
}
    



?>

