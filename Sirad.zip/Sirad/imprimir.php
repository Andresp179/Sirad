<?php

session_start();
    $fecha=date('d');
    $fecha.=' de '.aCadena(date('m')).' del '.date('Y');
    $contenido='<page><div style="width: 100%;margin: 0 100%;align=left">Reporte de Asistencia Docente
                <br/>'.$fecha.'.<br/><br/>'.crearTabla($_SESSION["reporte"]).'</div></page>';
  
    require_once('creadorPDF/html2pdf_v4.03/html2pdf.class.php');;
    $pdf=new HTML2PDF("P",'A4','fr','UTF-8');
    $pdf->writeHTML($contenido);
    $pdf->pdf->IncludeJS('print(TRUE)');
    $pdf->Output('Reporte Actividad.pdf');
 
    function aCadena($mes){
        $mes=  intval($mes);
        switch($mes){
            case 1: return "Enero";
            case 2: return "Febrero";
            case 3: return "Marzo";
            case 4: return "Abril";
            case 5: return "Mayo";
            case 6: return "Junio";
            case 7: return "Julio";
            case 8: return "Agosto";
            case 9: return "Septiembre";
            case 10: return "Octubre";
            case 11: return "Noviembre";
            case 12: return "Diciembre";
        }
    }
    
    function crearTabla($array){
            $tabla='<table style="border:  1px solid #333;border-collapse: collapse;padding: 0 5px ;width:100%">';
            $tabla.='<tr><td style="border:  1px solid #333; font-weight: bold; width=100%" colspan="8">Asistencia de Docentes:</td></tr>';
            $tabla.='<tr><td style="border:  1px solid #333; padding: 0 5px">Nombre</td><td style="border:  1px solid #333; padding: 0 5px">Aapellido</td><td style="border:  1px solid #333; padding: 0 5px">Asistencia</td><td style="border:  1px solid #333; padding: 0 5px">Fecha</td><td style="border:  1px solid #333; padding: 0 5px">Hora</td><td style="border:  1px solid #333; padding: 0 5px">Salon</td><td style="border:  1px solid #333; padding: 0 5px">Materia</td><td style="border:  1px solid #333; padding: 0 5px">Descripcion</td></tr>';
    for($i=0;$i<count($array);$i++){
         $use =  split(",", $array[$i]);
    $tabla.='<tr><td style="border:  1px solid #333; padding: 0 5px">'.$use[0].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[1].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[2].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[3].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[4].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[5].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[6].'</td><td style="border:  1px solid #333; padding: 0 5px">'.$use[7].'</td></tr>';
           
    }
         $tabla.='</table>';
            
        return $tabla;
    }

?>