<?php
session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");

$requerimiento=$_POST['requerimiento'];
$id=$_POST['id'];

if($requerimiento=="EditarUsuario"){
    $consult= "select * from usuario where id='$id'";
    $resultados=  mysql_query($consult,$conexion);
    while($doc=  mysql_fetch_array($resultados)){
    $_SESSION['id']=$id;
    $_SESSION['nombre']=$doc['nombre_usuario'];
    $_SESSION['apellido']=$doc['apellido'];
    $_SESSION['tipodocumento']=$doc['tipo_documento'];
    $_SESSION['documento']=$doc['documento'];
    $_SESSION['contrasena']=$doc['contrasena'];
    $_SESSION['sexo']=$doc['sexo'];
    $_SESSION['tipouser']=$doc['tipo_usuario'];
    $_SESSION['estado']=$doc['estado'];
    }
    mysql_close($conexion);
    header("location: editusuario.php");
}else if($requerimiento=="EliminarUsuario"){
    $consulta="select * from usuario where id='".$id."' and documento='".$_SESSION['documentologin']."'";
    $resultado=  mysql_query($consulta,$conexion);
    $total=  mysql_num_rows($resultado);
    if($total>0){
        $array=array("status"=>"Error","msg"=>"Error, no se puede eliminar el usuario, ya que este inicio sesion.");
        mysql_close($conexion);
    }else{
        $consulta2="delete from usuario where id='".$id."'";
        mysql_query($consulta2,$conexion);
        mysql_close($conexion);
        $array=array("status"=>"Error","msg"=>"El usuario ha sido eliminado.");
    }
    print_r(json_encode($array));
} 
?>
