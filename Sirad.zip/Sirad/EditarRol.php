<?php
session_start();
$nombre= $_SESSION['nombreroleditar'];
$descripcion= $_SESSION['descripcionroleditar'];
$privile=$_SESSION['privilegioroleditar'];
   
?>




<form action="" method="post">
        	<table  id="tabla"  >
                     <div id="ponder">

            	<tr>  
                	<td class="field"> <label> Nombre :</label></td>   
                        <td> <textarea  class="areaEditar" name="nombre"   placeholder=" Digite El Nombre.." required="required"><?php echo $nombre; ?></textarea></td>
                </tr>
            	<tr>  
                <br>
                	<td class="field"> <label > Descripcion :</label></td>   
                        <td> <textarea name="descripcion" required="required" class="area" placeholder="Digite La Descripcion Del Rol"><?php echo $descripcion ?> </textarea> </td>
                </tr>
                <tr>  
                	<td class="field"> <label> Privilegios :</label></td>   
                        <td>
                            <div id="contechebox">
                                <br>
                            <?php 
                                $conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
                                $db=mysql_select_db("registro")or die("Error en la Base de datos");
                                $consulta="select * from privilegio";
                                $Result=  mysql_query($consulta,$conexion);
                                while($vector = mysql_fetch_array($Result)){
                                    if(in_array($vector['idprivilegio'],$privile)){ 
                                        echo " <input type='checkbox' checked='checked' value='".$vector['idprivilegio']."' name='".$vector['idprivilegio']."' id=chebox /> ".$vector['descripcion']." <br>";
                                    }else{
                                        echo " <input type='checkbox' value='".$vector['idprivilegio']."' name='".$vector['idprivilegio']."' id=chebox /> ".$vector['descripcion']." <br>";
                                    }
                                }
                             ?>  
                            </div>
                        </td>
                </tr>
            </table>
            
            <div id="contenedorBotones1">
            <input type="submit" value="Guardar" class="boton1"/>
            <input type="button" value="Volver" class="boton1" onclick="cargarDiv('Roles.php') " />
            </div>
   
        </form>

 