
 
 <h1>Ingresar un Salon<h1>
 
 <form action="datos/salon.php" method="post"><table width="300" border="0" cellspacing="20" cellpadding="20">
  <tr>
    <td ><label>Nombre:</label></td>
    <td >
     
        <input type="text" name="nombre" id="nombre" required="required" placeholder="Introduzca un Nombre"/></td>
  </tr>
  <tr>
    <td><label>Descripcion:</label>&nbsp;</td>
    <td><label for="descripcion"></label>
        <textarea name="descripcion" id="descripcion" required="required"  placeholder="Introduzca una descripcion" rows="10" cols="40" ></textarea></td>
  </tr>
  
</table>
     <input type="submit" value="Ingresar Salon" />
</form>
