<?php


session_start();
//$id=$_SESSION["iduser"];
$consul= "select * from rol";
$res= mysql_query($consul);
$cn = mysql_connect("localhost","root","")or die ("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");
$consul= "select * from rol";
$res= mysql_query($consul);

$consult= "select * from usuario where id='2'";
//print_r($consult);
$result= mysql_query($consult,$cn);
$total=  mysql_num_rows($result);


 if($total==$total){ 
$doc=  mysql_fetch_array($result);
$_SESSION["nombre"]=$doc['nombre_usuario'];
$_SESSION["apellido"]=$doc['apellido'];
$_SESSION["tipo_documento"]=$doc['tipo_documento'];
$_SESSION["documento"]=$doc['documento'];
$_SESSION["sexo"]=$doc['sexo'];
$_SESSION["estado"]=$doc['estado'];

 }
$sexonombre="Masculino";
$otrosex="<option value='F'>Femenino</option>";
if($_SESSION['sexo']=='f'){
  $sexonombre="Femenino";
  $otrosex="<option value='M'>Masculino</option>";
 }
 $sexocomb="<option value='".$_SESSION['sexo']."'>".$sexonombre."</option>".$otrosex;
if(empty($_SESSION['sexo'])){
    $sexocomb="<option value=''>Seleccione Sexo</option> 
             <option value='F'>Femenino</option>
<option value='M'>Masculino</option>";
}   
    
$tipdoc="Tarjeta de Identidad";
$otrodoc="<option value='Cedula'>Cedula</option>";
if($_SESSION['tipo_documento']=='Cedula'){
  $tipdoc="Cedula";
  $otrodoc="<option value='Tarjeta de Identidad'>Tarjeta de Identidad</option>";
 }
 $documentcomb="<option value='".$_SESSION['tipo_documento']."'>".$tipdoc."</option>".$otrodoc;
if(empty($_SESSION['tipo_documento'])){
    $documentcomb="<option value=''>Seleccione Tipo de Documento</option> 
             <option value='Tarjeta de Identidad'>Tarjeta de Identidad</option>
<option value='Cedula'>Cedula</option>"; }       
            
 $estado="Activo";
$otroestado="<option value='Inactivo'>Inactivo</option>";
if($_SESSION['estado']=='Activo'){
  $estado="Activo";
  $otroestado="<option value='Inactivo'>Inactivo</option>";
 }
 $estadocomb="<option value='".$_SESSION['estado']."'>".$estado."</option>".$otroestado;
if(empty($_SESSION['tipo_documento'])){
    $estadocomb="<option value=''>Seleccione Estado</option> 
             <option value='Activo'>Activo</option>
<option value='Inactivo'>Inactivo</option>";           
    
    
}
?>
<form  action="datos/eliminarusuario.php" method="post">

<table width="300" border="0" cellspacing="20" cellpadding="20">
     <tr>
       <td width="150"><label>Nombre:</label>&nbsp;</td>
       <td width="150"><label for="nombre"></label>
         <input type="text" name="nombre" id="nombre" required="required" placeholder="Escriba el Nombre" value=<?php echo $_SESSION["nombre"];?>></td>
     </tr>
     <tr>
       <td>Apellido:</td>
       <td><label for="apellido"></label>
         <input type="text" name="apellido" id="documento2" required="required" placeholder="Escriba el Apellido" value=<?php echo $_SESSION["apellido"];?>></td>
     </tr>
     <tr>
       <td><label>Tipo de Documento:</label>&nbsp;</td>
       <td><select ><?php echo $documentcomb ?></select></td>
     </tr>
     <tr>
       <td><label>Documento:</label>&nbsp;</td>
       <td><label for="documento3"></label>
         <input type="text" name="documento" id="documento3" required="required" placeholder="Escriba el Documento" value=<?php echo $_SESSION["documento"];?>></td>
     </tr>
     
        <tr>
       <td><label>Sexo:</label>&nbsp;</td>
       <td><select name="sex"><?php    echo $sexocomb?>;</select>
        </td>
     </tr>
     <tr>
       <td><label>Tipo de Usuario:</label>&nbsp;</td>
       <td><label for="user"></label>
         <select name="user" id="user">
           <option>Seleccione Tipo de Usuario</option>
           <?php  while ($fila= mysql_fetch_array($res)){
           $x=$fila['id_rol'];
		   ?>
           <option value="<?php echo $x ?>"><?php echo $fila['nombre']?></option>
           <?php } ?>
         </select></td>
     </tr>
     <tr>
       <td><label>Estado:</label>&nbsp;</td>
       <td>
           <select name="estado"><?php echo $estadocomb ?>;</select>
        </td>
     </tr>
     <tr>
     <input >
     </tr>
</table><input type="submit" value="Eliminar" />
</form>



