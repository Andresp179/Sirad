<?php
session_start();
if (isset($_SESSION['mensajeRta'])) {
    $error = $_SESSION['mensajeRta'];
    $_SESSION['mensajeRta'] = "";
    echo "<script>alert('" . $error . "');</script>";
    unset($_SESSION['mensajeRta']);
}
?>
<head>
    
 <script src="js/jquery.js"></script>
 <script src="js/funciones.js"></script>
</head>
<form  action="datos/reportes.php"  method="post">
    
  <table class="tablaFiltro">
				<tr>
					<th colspan="6">&nbsp;&nbsp;Filtro de B&uacute;squeda</th>
				</tr>
				<tr>
					<td><label class="">Fecha Inicio:</label></td>
					<td><input class="campoform" type="date" name="fechainicio" id="fechaIReporte" required="required"></td>
					<td><label class="">Fecha Fin:</label></td>
					<td><input class="campoform" type="date" name="fechafin" id="fechaFReporte" required="required"></td>
				</tr>
				<tr>
					  
  </table>
    
    <input type="button" value="Generar" onclick="reportes();" />
     <input type="hidden" name="requerimiento" id="reporte" value="reporte">
                                
    
</form>
<div id="respuesta"
<?php
 echo "";
?>
</div>



