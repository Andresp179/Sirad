
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="datos/estilos.css">
</head>
<div id="filtro" class="contenedor">
    <table class="tablaFiltro">
        <tr>  
            <th coslpan="4">Filtro de busqueda</th>
        </tr>
        <tr>
            <td><label class="nombreFieldFiltro">Fecha de Registro:</label></td>
            <td><input class="campoform" type="date" name="fecharegistro" id="fechaUsu"></td>
            <td>
                <select class="combo" name="sexo" id="sexo">
                    <option value='' >Seleccione un Sexo...</option>
                    <option value='M'>Hombre</option>
                    <option value='F'>Mujer</option>
                </select>            
                
            </td>
        </tr>
        <tr>
        <td><label class="nombreFieldFiltro">Rol:</label></td>
        <td>
            <select class="combo" name="rol" id="rolUsu">
                <option value=''> Seleccione un  rol...</option>
                 <?php  while ($fila= mysql_fetch_array($res)){
           $x=$fila['id_rol'];
		   ?>
           <option value="<?php echo $x ?>"><?php echo $fila['nombre']?></option>
           <?php } ?>
            </select></td>
            <td><input class="campoform" type="text" name="documento" id="documentusu" placeholder="Digite N° de documento...."></td>
    </tr>
    <tr>
        <td><label class="nombreFieldFiltro">Estado:</label></td>
        <td>
            <select class="combo" name="estado" id="estado2">
                <option value=''>Seleccione el estado...</option>
                <option value='Activo'>Activo</option>
                <option value='Eliminado'>Eliminado</option>
            </select>           
            
        </td>   
        
        
        
    </tr>    
        
    </table>    
    <div id="respuesta">
      <?php
     function ListarUsuarios(){
$cn= mysql_connect('localhost','root','')or die ("Problemas con la Conexion a la Base de Datos");
 mysql_select_db('registro') or die ("Error en la base de Datos");
$consultuser= "select * from usuario where estado='activo'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuarios(){
    $user=ListarUsuarios();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td> 
           <img src='Imagenes/editar.png' width='15' height='15' onclick='EditarUsuario($use[0]);'/>
           <img src='Imagenes/eliminar.png' width='15' height='15'/></td></tr>";    
           
    }
    
    echo $tabla;
}
    
      ?>
        
    </div>
</div>  
</html>