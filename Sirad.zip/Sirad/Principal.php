﻿<?php
session_start();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

     <script>
 
    function cargar(div,url){
	$(div).load(url);
    }
   
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sirad</title>

 <link rel="stylesheet" type="text/css" href="datos/estilos.css">

</head>
 
<body>
   
<div id="cabezal">  
<div id ="izq">
     <img src="Imagenes/ASISTENCIA.jpg" width="60px" height="55px" />
     </div>
    <div id="der">   
    <?php
	$modulos =$_SESSION['modulo'];
         
	if(in_array("Usuarios",$modulos)){
	  ?>
	<a href="Javascript: cargar('#principal','EditarUsuarios.php')">
            <img src ="Imagenes/user.png" width="50" height="50" />
	</a>  
         <img src ="Imagenes/separador.png" width="5" height="50" />  
 <?php
 }
    ?>
       
        <?php
     $modulos =$_SESSION['modulo'];  
     if(in_array("Asistencia",$modulos)){
         ?>
        <a href="Javascript: cargar('#principal','Asistencia.php')">
            <img src="Imagenes/asisten.png" width="50" height="50"/>
        </a>
         <img src ="Imagenes/separador.png" width="5" height="50" /> 
     <?php   
     }
        ?>
        
        <?php
        $modulos =$_SESSION['modulo'];
        if(in_array("Roles",$modulos))  {      
        ?>
        <a href="Javascript: cargar ('#principal','editrol.php')">
            <img src="Imagenes/roles.png" width="50" height="50" />
        </a>
         <img src ="Imagenes/separador.png" width="5" height="50" /> 
        <?php
        }
        ?>
         <?php
         
         
         $modulos =$_SESSION['modulo'];
         if(in_array("salones",$modulos)){
         ?>
         <a href="Javascript: cargar ('#principal','Salon.php')">
         <img src="Imagenes/salon.png" width="50" height="50"/>
         </a>
         <img src ="Imagenes/separador.png" width="5" height="50" /> 
         <?php
         }
         ?>     
         
         <?php   
         
         $modulos =$_SESSION['modulo'];
         if(in_array("Reportes",$modulos)){
         ?>
         <a href="Javascript: cargar ('#principal','Reportes.php')">
             <img src="Imagenes/reportes.png" width="50" height="50"/>
         </a>
         <img src ="Imagenes/separador.png" width="5" height="50" /> 
         <?php
         }
         ?>         
         <a href="CerrarSesion.php" >
             <img src="Imagenes/cerrarSesion.png" width="50" height="50"/>
         </a>
         <img src ="Imagenes/separador.png" width="5" height="50" /> 
         <?php
         
         ?>
         <label class=""onclick= "Javascript: cargar('#principal','Perfil.php')">Perfil</label> 
      
     
      
      
      
      
      
</div>

</div>  
<div id="principal">           

</div>
    <script src="js/jquery.js"></script><script src="js/funciones.js"></script>
<footer>
<p>Departamento de TIC - Universidad Libre Seccional C&uacute;cuta</p><br>
<p>Copyright © Todos los derechos Reservados</p>            <br>
<p><b>sistemas@unilibrecucuta.edu.co</b></p>
</footer>  
</body>
</html>
<?php
    if($_SESSION['mensaje']=="se ha creado la tabla"){
       ?>
        <script>
              $("#principal").load("Reportes.php");
        </script>
        <?php
    }
?>