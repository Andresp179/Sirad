<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registrar un Programa</title>
<link rel="stylesheet"  href="estilos.css"/>
</head>

<body>
<div id="cabezal">
 <div id ="izq">
    <img src="Imagenes/images.jpg" width="70" height="70" />
      </div>
       </div>    
  <div id="principal">
  <h1>Ingresar un Programa<h1>
  <div id="centrar">
  <form action="datos/programa.php" method="post" id="formPrograma"><table width="300" border="0" cellspacing="20" cellpadding="20">
  <tr>
    <td width="150"><label>Nombre:</label>&nbsp;</td>
    <td width="150"><label for="nombre"></label>
      <input type="text" name="nombre" id="nombre" placeholder="Escriba un Nombre" required="required"/></td>
  </tr>
  <tr>
    <td><label>Descripcion:</label>&nbsp;</td>
    <td><label for="descripcion"></label>
      <textarea name="descripcion" id="descripcion" cols="45" rows="5" placeholder="Escriba una Descripcion" required="required"></textarea></td>
  </tr>
</table>
    <p>
      <input type="submit" name="Ingresar" id="Ingresar" value="Registrar" />
    </p>
  </form>
  </div>
  </div>
   <footer>
			<p>Departamento de TIC - Universidad Libre Seccional C&uacute;cuta</p><br>
			<p>Copyright © Todos los derechos Reservados</p>
            <br>
			<p><b>sistemas@unilibrecucuta.edu.co</b></p>
		</footer>
</body>
</html>