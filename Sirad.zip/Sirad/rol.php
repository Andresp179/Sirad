<?php
session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");
$requerimiento=$_POST['requerimiento'];
$id=$_POST['id'];
if($requerimiento=="consultarRol"){
    $consulta="select r.descripcion,r.nombre,r.id_rol,p.privilegio from rol r inner join rolprivilegio p on r.id_rol=p.rol where r.id_rol='".$id."'";
    $pri=array();
    $resultados=  mysql_query($consulta,$conexion);
    while($doc=  mysql_fetch_array($resultados)){
    $_SESSION['idroleditar']=$id;
    $pri[]=$doc['privilegio'];
    $_SESSION['descripcionroleditar']=$doc['descripcion'];
    $_SESSION['nombreroleditar']=$doc['nombre'];
    }
    $_SESSION['privilegioroleditar']=$pri;
}
?>

