<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
session_start();
//include_once("EditarUsuarios.php");
$cn = mysql_connect("localhost","root","")or die ("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");

$consult= "select * from rol";
$res= mysql_query($consult);

		   

?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    
 <script src="js/jquery.js"></script>
 <script src="js/funciones.js"></script>
 <script>
    function cargar(div,url){
	$(div).load(url);
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sirad</title>
</head>
<link rel="stylesheet" type="text/css" href="datos/estilos.css"/>
<body>
    
    <form  action="" method="POST">
    
        
    
           <?php
          $vector=$_SESSION['privilegiorol'];
        if(in_array("6",$vector)){ 
            ?>
           
           <?php
        }
        ?>
         
           
           
           <div id="respuesta">
               
               <?php
               listarTodosUsuarios();
               ?>
               <?php

 function ListarUsuarios(){
$cn= mysql_connect('localhost','root','')or die ("Problemas con la Conexion a la Base de Datos");
 mysql_select_db('registro') or die ("Error en la base de Datos");
$consultuser= "select * from usuario where estado='activo'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre_usuario'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuarios(){
    $user=ListarUsuarios();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
      $id=$use[0];
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td><img src='Imagenes/editar.png' width='15' height='15' id='indice_".$id."' onclick='EditarUsuario.call(this);' >               
            <img src='Imagenes/eliminar.png' width='15' height='15' id='indice_".$id."' onclick='EliminarUsuario.call(this);' >


           </td></tr>";    
           
    }
    
    echo $tabla;
}
?>
           </div>
    </div>
        
   </body>
<div id="ponder">
<a href="Javascript: cargar('#principal','RegistroUsuarios.php')">
    <img src="Imagenes/Ingresar.png" width="80" height="80" >
</a>
</div>
</html> 
    
