<?php
session_start();

$requerimiento = $_POST['requerimiento'];

if($requerimiento=='reporte'){
$cn = mysql_connect("localhost","root", "") or die("Error en la conexion a la base de datos");
$db = mysql_select_db("registro") or die ("Error en la base de datos");
$inicio =$_POST['fechaI'];
$fin=$_POST['fechaF'];

$consultaa="select * from asistencia where fecha between '$inicio' and '$fin' ";
$sql= mysql_query($consultaa,$cn);
$total=  mysql_num_rows($sql);
$usu=array();

$requerimiento = $_POST['requerimiento'];

if($total>0){
     $tabla="<table border>
               <tr><td colspan='8'>Resultados Encontrados</td></tr>
               <tr><td>Nombre</td>
               <td>Apellido</td>
               <td>Asistencia</td>
               <td>Fecha</td>
               <td>Hora</td>
               <td>Salon</td>
               <td>Materia</td>        
               <td>Descripcion</td></tr>";
     $reporte="";
    while($doc=  mysql_fetch_array($sql)){
        $tabla.="<tr><td>$doc[nombre]</td>
                <td>$doc[apellido]</td>
                <td>$doc[asistencia]</td>
                <td>.$doc[fecha]</td>
                <td>$doc[hora]</td>
                <td>$doc[salon]</td>
                <td>$doc[materia]</td> 
                <td>$doc[descripcion]</td> 
                </tr>";
        $reporte[]=$doc['nombre'].",".$doc['apellido'].",".$doc['asistencia'].",".$doc['fecha'].",".$doc['hora'].",".$doc['salon'].",".$doc['materia'].",".$doc['descripcion'];
    }
    $_SESSION['reporte']=$reporte;
         $tabla.="</table>";
         $tabla.="<button><a href='imprimir.php' target='blanch'>Imprimir</button></a>";
   
         echo $tabla;
   
} else{
       //echo "No Hay Reportes Para Mostrar en ese Rango de Fechas";  
       echo "No Hay Reportes en el Rango de Fechas";
}

}
    
    
    

?>

		