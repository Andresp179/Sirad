<?php
session_start();
$hoy = date("Y-m-d");
date_default_timezone_set('America/Bogota');
$hora = date("h:i a");
$cn = mysql_connect("localhost", "root", "")or die("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die("Error en la base de Datos");
$consult = "select * from salon";
$res = mysql_query($consult);
?>



<form action="datos/asistencia.php" method="post">
    <table width="300"   border="0" cellspacing="20" cellpadding="20">

        <tr>
            <td width="150"><label>Nombre:</label>&nbsp;</td>
            <td width="150"><label for="nombre"></label>
                <input type="text" name="nombre" id="nombre" required="required" placeholder="Escriba el Nombre" ></td>
        </tr>

        <tbody>
            <tr>
                <td><label>Apellido:</label></td>
                <td><input type="text" name="apellido" id="apellido" required="required" placeholder="Escriba el Apellido"></td>
            </tr>
            <tr>
                <td><label>Asistencia:</label></td>
                <td><label for="asistencia"></label>
                    <select name="asistencia" id="asistencia">
                        <option>Seleccione Opcion</option>
                        <option>Asistio</option>
                        <option>No Asistio</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Fecha:</label></td>
                <td><input type="text" name="fecha" id="fecha" value="<?php echo $hoy ?>" ></td>
            </tr>
            <tr>
                <td><label>Hora:</label></td>
                <td><input type="text" name="hora" id="hora" value="<?php echo $hora ?>"></td>
            </tr>
            <tr>
                <td><label>Salon:</label></td>
                <td><select name="salon" id="user">
                        <option>Seleccione Salon</option>
                        <?php
                        while ($fila = mysql_fetch_array($res)) {
                            $x = $fila['nombre'];
                            ?>
                            <option value="<?php echo $x ?>"><?php echo $fila['nombre'] ?></option>
                        <?php } ?>
                    </select></td>
            </tr>
            <tr>
                <td><label>Materia:</label></td>
                <td><input type="text" name="materia"id="materia" required="required" placeholder="Escriba Materia" ></td>
            </tr>
            <tr>
                <td><label>Descripcion:</label></td>
                <td><textarea name="descripcion" required="required" placeholder="Escriba descripcion" rows="10" cols="40"></textarea></td>
            </tr>

        </tbody>

    </table>
    <input type="submit" value="Ingresar Asistencia" value="Ingresar" action="js/funciones.js" />
</form>