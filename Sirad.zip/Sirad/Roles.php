
 
<form action="datos/roles.php" method="post" id="formRoles">
<table width="300" border="0" cellspacing="20" cellpadding="20">
  
  
  <tr>
  <h1>Registrar Roles:</h1>
    <td><label>Nombre:</label></td>
    <td><label for="nombre"></label>
      <input type="text" name="nombre" id="nombre" placeholder="Escriba el Nombre del Rol" required="required"/></td>
  </tr>
  <tr>
    <td><label></label>
    Descripcion:</td>
    <td><label for="descripcion"></label>
      <textarea name="descripcion" id="descripcion" cols="45" rows="5" placeholder="Escriba una descripcion" required="required"></textarea></td>
  </tr>
</table>
<input type="submit" id="ingresar" value="Registrar Rol" name="btn" action="">
</form>

  