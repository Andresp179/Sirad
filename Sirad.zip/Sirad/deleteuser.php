<?php
session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");
$requerimiento=$_POST['requerimiento'];
$id=$_POST['id'];
if($requerimiento=="EditarUsuario"){
    $consult= "select * from usuario where id='$id'";
    $pri=array();
    $resultados=  mysql_query($consulta,$conexion);
    while($doc=  mysql_fetch_array($resultados)){
    $_SESSION['id']=$id;
    $_SESSION['nombre']=$doc['nombre_usuario'];
    $_SESSION['apellido']=$doc['apellido'];
    $_SESSION['tipodocumento']=$doc['tipo_documento'];
    $_SESSION['documento']=$doc['documento'];
    $_SESSION['contrasena']=$doc['contrasena'];
    $_SESSION['sexo']=$doc['sexo'];
    $_SESSION['tipouser']=$doc['tipo_usuario'];
    $_SESSION['estado']=$doc['estado'];
    }
$_SESSION['privilegioroleditar']=$pri;}

?>

