$(function() {
    //El boton desencadena la accion
    $('#Ingresar').click(function() {
        //Se verifica si la opcion del select esta vacia
    if ($('#tipdocumento').val().trim() === 'Seleccione Tipo de Documento') {
            alert('Seleccione Documento');
        }
      
    });
});
$(function() {
    //El boton desencadena la accion
    $('#ingresar').click(function() {
        //Se verifica si la opcion del select esta vacia
        if ($('#user').val().trim() === 'Seleccione Tipo de Usuario') {
            alert('Seleccione tipo de Usuario');
        }
      
    });
});
$(function() {
    //El boton desencadena la accion
    $('#ingresar').click(function() {
        //Se verifica si la opcion del select esta vacia
        if ($('#sexo').val().trim() === 'Seleccione Sexo') {
            alert('Seleccione Sexo');
        }
      
    });
});
$(function() {
    //El boton desencadena la accion
    $('#ingresar').click(function() {
        //Se verifica si la opcion del select esta vacia
        if ($('#estado').val().trim() === 'Seleccione Estado') {
            alert('Seleccione Programa');
        }
      
    });
});

function EditarUsuario(){ 
 var id=(this.id).split("_")[1];
 var url= "edituser.php";
 var misdatos={id:id,requerimiento:"EditarUsuario"};
 $.post(url,misdatos,function(datos){
     $("#principal").load("editusuario.php");
 }).fail(function(error){console.log(error)});  
}

function reportes(){
    var requerimiento=document.getElementById("reporte").value;
    var fechaI=document.getElementById("fechaIReporte").value;
    var fechaF=document.getElementById("fechaFReporte").value
    var url="reportes_1.php";
    var datos={fechaI:fechaI,fechaF:fechaF,requerimiento:requerimiento}
    $.post(url,datos,function(resultado){
        //alert(resultado);
        if(resultado=="false"){
            alert("No existen registros para este rango de fechas");
        }
            document.getElementById("respuesta").innerHTML=resultado;
        
    }).fail(function(error){console.log(error)})
    
      
}
function EliminarUsuario(){
    var id=(this.id).split("_")[1];
    var url= "edituser.php";
    var misdatos={id:id,requerimiento:"EliminarUsuario"}
    $.post(url,misdatos,function(datos){
        var mijson=JSON.parse(datos);
        if(mijson.status=="error"){
            alert(mijson.msg);
            return;
        }
        alert(mijson.msg);
        $("#principal").load("EditarUsuarios.php");
    }).fail(function(error){console.log(error)});  
}

function EditarRol(){ 
    var id=(this.id).split(",")[1];
    var url="rol.php";
    var misDatos={id:id,requerimiento:"consultarRol"}
    $.post(url,misDatos,function(resultado){
         $("#principal").load("EditarRol.php");
    }).fail(function(error){console.log(error)}); 
}