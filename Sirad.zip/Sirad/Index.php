<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Sirad</title>

        <link rel="stylesheet" type="text/css" href="datos/estilos.css">
    </head>

    <body>
        <?php
        $con = mysql_connect("localhost", "root", "andres321") or die("Problemas con la Conexion a la Base de Datos");
        $db = mysql_select_db("registro") or die("Error en la base de Datos");
        $consult = "select * from rol";
        $res = mysql_query($consult);
        ?>
        <div id="cabezal"> 
            <div id ="izq"> 
                <img src="Imagenes/images.jpg" width="50" height="55" />
            </div>
        </div>   
        <div id="principal"> 
            <div id="centrar">
                <div id="logo" class="logo">
                    <img id="logo" src="./Imagenes/ASISTENCIA.jpg">
                </div></div>
            <div class="mensaje">Inicia Sesi&oacute;n y Podr&aacute;s Realizar  La Respectiva Asistencia Docente.</div>
            <form action="datos/controlador.php" method="post">
                <div class="itemForm">
                    <img src="Imagenes/documento.png" class="icono">
                    <input class="campo" type="text" name="documento" placeholder=" Digite su Documento de Identidad..." required>
                </div> 
                <div class="itemForm">
                    <img src="Imagenes/password.png" class="icono">
                    <input class="campo" type="password" name="clave" placeholder=" Digite su Contrase&ntilde;a..." required>
                </div>
                <div class="itemForm">
                    <img src="Imagenes/tipoUsuario.png" class="icono">
                    <select name="tipousuario" class="select">
                        <option>Seleccione el Tipo de Usuario</option>
                        <?php
                        while ($fila = mysql_fetch_array($res)) {
                            $x = $fila['id_rol'];
                            ?>
                            <option value="<?php echo $x ?>"><?php echo $fila['nombre'] ?></option>
<?php } ?>
                    </select>
                </div>	

                <input type="hidden" name="requerimiento" value="Iniciar Sesion">
                <input class="boton" type="submit" value="Iniciar Sesión" onmouseover="this.className = 'boton botonVisited'" onmouseout="this.className = 'boton'">
            </form>
        </div>






        <footer>
            <p>Departamento de TIC - Universidad Libre Seccional C&uacute;cuta</p><br>
            <p>Copyright © Todos los derechos Reservados</p>
            <br>
            <p><b>sistemas@unilibrecucuta.edu.co</b></p>
        </footer>   
    </body> 
</html>