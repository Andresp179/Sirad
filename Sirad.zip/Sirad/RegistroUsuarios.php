
 <?php
 session_start();
$cn = mysql_connect("localhost","root","")or die ("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");
$consult= "select * from rol";
$res= mysql_query($consult);
/* while ($fila= mysql_fetch_array($res))
echo $fila['nombre'];
*/
?>
  
<html>
 <form action="datos/registrousuario.php" method="post" id ="formPrograma">
     
   <table width="300" border="0" cellspacing="20" cellpadding="20">
     <tr>
       <td width="150"><label>Nombre:</label>&nbsp;</td>
       <td width="150"><label for="nombre"></label>
         <input type="text" name="nombre" id="nombre" required="required" placeholder="Escriba el Nombre" /></td>
     </tr>
     <tr>
       <td>Apellido:</td>
       <td><label for="apellido"></label>
         <input type="text" name="apellido" id="documento2" required="required" placeholder="Escriba el Apellido"/></td>
     </tr>
     <tr>
       <td><label>Tipo de Documento:</label>&nbsp;</td>
       <td><label for="tipdocumento"></label>
         <select name="tipdocumento" id="tipdocumento">
           <option>Seleccione Tipo de Documento</option>
           <option>Cedula</option>
           <option>Tarjeta de Identidad</option>
         </select></td>
     </tr>
     <tr>
       <td><label>Documento:</label>&nbsp;</td>
       <td><label for="documento"></label>
         <input type="text" name="documento" id="documento" required="required" placeholder="Escriba el Documento" /></td>
     </tr>
     <tr>
       <td><label>Contrasena:</label>&nbsp;</td>
       <td><label for="contrasena"></label>
         <input type="password" name="contrasena" id="contrasena" required="required" placeholder="Escriba la Contraseña" /></td>
     </tr>
     <tr>
       <td><label>Sexo:</label>&nbsp;</td>
       <td><label for="sexo3"></label>
         <select name="sexo" id="sexo3">
           <option>Seleccione Sexo</option>
           <option>M</option>
           <option>F</option>
         </select></td>
     </tr>
     <tr>
       <td><label>Tipo de Usuario:</label>&nbsp;</td>
       <td><label for="user"></label>
         <select name="user" id="user">
           <option>Seleccione Tipo de Usuario</option>
           <?php  while ($fila= mysql_fetch_array($res)){
           $x=$fila['id_rol'];
		   ?>
           <option value="<?php echo $x ?>"><?php echo $fila['nombre']?></option>
           <?php } ?>
         </select></td>
     </tr>
     <tr>
       <td><label>Estado:</label>&nbsp;</td>
       <td><label for="estado2"></label>
           <select name="estado" id="estado2" >
           <option>Seleccione Estado</option>
           <option>Activo</option>
           <option>Inactivo</option>
         </select></td>
     </tr>
     
   </table>
   <p>
     <input type="submit" name="Ingresar" id="Ingresar" value="Ingresar Usuario" action="js/funciones.js" />
   </p>
     
 </form>
 <script src="js/jquery.js"></script>
 <script src="js/funciones.js"></script>
</html>

