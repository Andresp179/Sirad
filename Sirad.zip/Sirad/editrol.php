
<?php

$cn = mysql_connect("localhost", "root", "") or die ("Error en la conexion");
$db =  mysql_select_db("registro") or die ("Error en la base de datos");

$consultrol ="select * from rol";
$result =  mysql_query($consultrol,$cn);
$total = mysql_num_rows($result);

$usu=array();
if($total>0){
     $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Descripcion</td>
               <td>Acciones</td>";
    while($doc=  mysql_fetch_array($result)){
        $id=$doc['id_rol'];
//     $usu[]=  $doc['nombre'].",". $doc['apellido'].",". $doc['asistencia'].",".$doc['fecha'].",".$doc['hora'].",".$doc['salon'].",".doc['materia'].",".doc['descripcion'];  
        $tabla.="<tr><td>$doc[id_rol]</td>
                <td>$doc[nombre]</td>
                <td>$doc[descripcion]</td>
                <td>  <img src='Imagenes/editar.png' width='15' height='15' id='indice,".$id."' onclick='EditarRol.call(this);'/>               
                </td></tr>";  
      
        }                       
    
    echo $tabla;
     
    
    
}
?>
<div id="ponder">
<a href="Javascript: cargar('#principal','Roles.php')">
    <img src="Imagenes/Ingresar.png" width="80" height="80" >
</a>
</div>