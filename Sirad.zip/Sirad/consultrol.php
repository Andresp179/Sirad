

<?php
include("editrol.php");
session_start();
$requerimiento = $_POST['requerimiento'];
         if($requerimiento=="editarol"){
             $id= $_post["id_rol"];
             $_SESSION["idrol"]=$id;
                
         }

?>

