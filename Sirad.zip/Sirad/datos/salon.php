<?php
$cn= mysql_connect("localhost","root","") or die ("Error en la conexion");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");

$nombre =$_POST['nombre'];
$descripcion=$_POST['descripcion'];


$consult = "select * from salon where nombre='$nombre'";    
$resultado=mysql_query($consult,$cn);
$resul=  mysql_num_rows($resultado);
if ($resul==1){
    echo '<script language = javascript>
	alert("Salon Repetido.")
	self.location = "../Principal.php"
	</script>';
	}
        else{
$insert = "insert into salon(nombre,descripcion) values ('$nombre','$descripcion')";
$sql= mysql_query($insert,$cn);
echo '<script language = javascript>
	alert("Registro Creado.")
	self.location = "../Principal.php"
	</script>';	
mysql_close($cn);

}

    

?>