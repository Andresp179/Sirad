<?php
$cn = mysql_connect("localhost","root","") or die("Error en la Conexion");
$db = mysql_select_db("registro") or die ("Error en la Base de Datos");


$documento=$_POST['documento'];



$delete ="delete from usuario where documento='$documento'";
$sql= mysql_query($delete,$cn);
$resul=  mysql_num_rows($sql);
if($resul=1){
 echo '<script language = javascript>
	alert("Usuario Eliminado.")
	self.location = "../Principal.php"
	</script>';
 $close =  mysql_close();
}



?>

