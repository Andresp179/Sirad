<?php
$cn = mysql_connect("localhost","root","")or die("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$tipo_documento=$_POST['tipdoc'];
$documento=$_POST['documento'];
$sex= $_POST['sex'];
$tipo_user=$_POST['user'];
$estado=$_POST['estado'];

$actualizar="update usuario set nombre='$nombre', apellido='$apellido',tipo_documento='$tipo_documento',documento='$documento',sexo='$sex',tipo_usuario='$tipo_user',estado='$estado' where id='1'";

$sql= mysql_query($actualizar,$cn);
print_r($sql);
echo '<script language = javascript>
	alert("Registro Actualizado.")
	self.location = "../Principal.php"
	</script>';	
	mysql_close($cn);







?>

