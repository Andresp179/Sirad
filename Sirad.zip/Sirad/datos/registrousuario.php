<?php
$cn = mysql_connect("localhost","root","")or die("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$tipo_documento=$_POST['tipdocumento'];
$documento=$_POST['documento'];
$contrasena=$_POST['contrasena'];
$sex= $_POST['sexo'];
$tipo_user=$_POST['user'];
$estado=$_POST['estado'];


$consult = "select * from usuario where documento='$documento'";    
$resultado=mysql_query($consult,$cn);
$resul=  mysql_num_rows($resultado);
if ($resul==1){
    echo '<script language = javascript>
	alert("Registro Repetido.")
	self.location = "../Principal.php"
	</script>';
	}
        else{
$ingresar= "insert into usuario (nombre_usuario,apellido,tipo_documento,documento,contrasena,sexo,tipo_usuario,estado) values('$nombre','$apellido','$tipo_documento','$documento','$contrasena','$sex','$tipo_user','$estado')";
$sql= mysql_query($ingresar,$cn);
echo '<script language = javascript>
	alert("Registro Creado.")
	self.location = "../Principal.php"
	</script>';


		
	mysql_close($cn);
 
	}
	


?>