<?php
$cn = mysql_connect("localhost","root","") or die("Error en la conexion");
$db =  mysql_select_db("registro") or die("Error en la base de datos");

$nombre =$_POST['nombre'];
$apellido =$_POST['apellido'];
$asisten =$_POST['asistencia'];
$fecha =$_POST['fecha'];
$hora=$_POST['hora'];
$salon=$_POST['salon'];
$materia=$_POST['materia'];
$descripcion =$_POST['descripcion'];

$insert="insert into asistencia(nombre,apellido,asistencia,fecha,hora,salon,materia,descripcion) values('$nombre','$apellido','$asisten','$fecha','$hora','$salon','$materia','$descripcion')";
$sql= mysql_query($insert,$cn);
echo '<script language = javascript>
	alert("Registro Creado.")
	self.location = "../Principal.php"
	</script>';
	mysql_close($cn);
        
        
        
        ?>

