<?php

$cn =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");

$nombre=$_POST['nombre'];
$descripcion=$_POST['descripcion'];



$consult = "select * from role where nombre='$nombre'";    
$resultado=mysql_query($consult,$cn);
$resul=  mysql_num_rows($resultado);
if ($resul==1){
    echo '<script language = javascript>
	alert("Rol Repetido.")
	self.location = "../Principal.php"
	</script>';
	}
        else{

$insert= "insert into rol(nombre,descripcion)values('$nombre','$descripcion')";
$sql = mysql_query($insert,$cn);
echo '<script language = javascript>
	alert("Rol Creado.")
	self.location = "../Principal.php"
        </script>';	


        }

?>
