<?php
$cn = mysql_connect("localhost", "root","") or die ("Error en la conexion");
$db = mysql_select_db("registro") or die ("Error en la base de datos");

$sexo =$_POST['sexo'];
$rol =$_post['rol'];
$estado =$_POST['estado'];
$document=$_post['documento'];

function ListarUsuariosEstado(){
$consultuser= "select * from usuario where estado='$estado'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre_usuario'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuariosEstado(){
    $user=ListarUsuariosEstado();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td> 
           <img src='Imagenes/editar.png' width='15' height='15' onclick='EditarUsuario($use[0]);'/>
           <img src='Imagenes/eliminar.png' width='15' height='15'/></td></tr>";    
           
    }
    
    echo $tabla;
}

function ListarUsuarios1(){
$consultuser= "select * from usuario where documento='$documento'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre_usuario'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuariosdoc(){
    $user=ListarUsuarios1();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td> 
           
          </td></tr>";    
           
    }
    
    echo $tabla;
}

function ListarUsuariosRol(){
$consultuser= "select * from usuario where rol='$rol'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre_usuario'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuariosrRol(){
    $user=  ListarUsuariosRol();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td> </td></tr>";    
           
    }
    
    echo $tabla;
}
function ListarUsuariosSexo(){
$consultuser= "select * from usuario where sexo='$sexo'";
$result= mysql_query($consultuser,$cn);
$total=  mysql_num_rows($result);
$usu="";
if($total>0){
    while($doc=  mysql_fetch_array($result)){
      $usu[]= $doc['id'].",". $doc['nombre_usuario'].",". $doc['apellido'].",". $doc['tipo_documento'].",".$doc['documento'].",".$doc['sexo'].",".$doc['estado'];  
        }
       
    return $usu;
}

 return FALSE;   
}
function listarTodosUsuarios(){
    $user=  ListarUsuariosSexo();
    if($user!=false){
        $tabla="<table border>
               <tr><th colspan='8'>Resultados Encontrados</th></tr>
               <td>Id</td>
               <td>Nombre</td>
               <td>Apellido</td>
               <td>Tipo de Documento</td>
               <td>Documento</td>
               <td>Sexo</td>
               <td>Estado</td>        
               <td>Acciones</td>";
                       
    }
    for($i=0;$i < count($user);$i++){
      $use =  split(",", $user[$i]);
    $tabla.="<tr><td>$use[0]</td>
           <td>$use[1]</td>
           <td>$use[2]</td>
           <td>$use[3]</td>
           <td>$use[4]</td>
           <td>$use[5]</td>
           <td>$use[6]</td>
           <td> 
           
           </td></tr>";    
           
    }
    
    echo $tabla;
}