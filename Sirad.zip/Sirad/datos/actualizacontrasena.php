<?php

session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion ");
$db=mysql_select_db("registro")or die("Error en la Base de datos");


$contrasena= $_POST['contrasena'];
$nuevacontrasena= $_POST['nuevacontrasena'];
$confirmecontrasena=$_POST['confirmecontrasena'];

$consult ="select * from usuario where contrasena ='".$contrasena."' and documento ='".$_SESSION['documento']."'";
$resultado = mysql_query($consult,$conexion);
$total=  mysql_num_rows($resultado);

if($total ==1){
 if($nuevacontrasena==$confirmecontrasena){
    $actualiza ="update usuario set contrasena='$confirmecontrasena' where documento ='".$_SESSION['documento']."'";
    mysql_query($actualiza,$conexion);  
   echo '<script language = javascript>
	alert("Contraseña Actualizada.")
	self.location = "../Principal.php"
	</script>';  
     mysql_close($conexion);
 
     
       
     
     
 } 

}
    



?>

