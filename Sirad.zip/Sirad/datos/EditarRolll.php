<?php
session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");


        $id;
        $consult="delete rol ".$act." where id_rol=$id";
	return mysql_query($consult, $link);

        
        
        
        
?>

