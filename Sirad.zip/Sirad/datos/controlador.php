<?php
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion a la Base de Datos");
$db=mysql_select_db("registro")or die("Error en la Base de datos");
//iniciamos la seccion


//guardamos los datos ingresados en el formulario
$documento=$_POST['documento'];
$clave=$_POST['clave'];
$user = $_POST['tipousuario'];



//hacemos la consulta ala base de datos para saber si el usuario se encuentra registrado
$consulta="select * from usuario where documento='".$documento."' and contrasena='".$clave."' and tipo_usuario ='".$user."'";

$resultado=mysql_query($consulta,$conexion)or die(mysql_error());
$resul=mysql_fetch_array($resultado);
$total=  mysql_num_rows($resultado);
//si los datos ingresados son incorrectos o el usuario no existe
if ($total<1)
{	
	mysql_close($conexion);
	echo '<script language = javascript>
	alert("Documento, Contrasena o tipo de usuario Incorrecto, por favor verifique.")
	self.location = "../Index.php"
	</script>';
	
}
//si el usuario y clave son correctos
else{
        session_start();
        $_SESSION['nombre']=$resul['nombre_usuario'];
        $_SESSION['apellido'] =$resul['apellido'];
	$_SESSION['documentologin']=$documento;
	$_SESSION['id_login']=$resul['id'];
	$_SESSION['id_rol_login']=$resul['tipo_usuario'];        
        $consulta2 = "select distinct m.nombre from modulo m, rolprivilegio r where r.rol='".$_SESSION['id_rol_login']."' and r.modulo=m.idmodulo"; 
        $resultado2=mysql_query($consulta2,$conexion)or die(mysql_error());
        $privilegios=array();
        $modulos=array();
        while($vector = mysql_fetch_array($resultado2)){
           $modulos[]=$vector['nombre'];
        }
        $consulta3 = "select * from  rolprivilegio where rol='".$_SESSION['id_rol_login']."' "; 
        $resultado3=mysql_query($consulta3,$conexion)or die(mysql_error());
        while($vector = mysql_fetch_array($resultado3)){
           $privilegios[] =$vector['privilegio'];
        }
        $_SESSION['privilegiorol']=$privilegios;
        $_SESSION['modulo']=$modulos;
        $_SESSION['mensaje']="";
        $_SESSION['tablareportes']="";
	mysql_close($conexion);
	header("Location: ../Principal.php");
}
?>




