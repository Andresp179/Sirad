<?php
session_start(); 
$cn = mysql_connect("localhost","root","")or die ("Problemas con la Conexion a la Base de Datos");
$db = mysql_select_db("registro") or die ("Error en la base de Datos");
?>
<form  action="datos/actualizarusuario.php" method="post">

<table width="300" border="0" cellspacing="20" cellpadding="20">
     <tr>
       <td width="150"><label>Nombre:</label></td>
       <td>  <input type="text" name="nombre" id="nombre" required="required" placeholder="Escriba el Nombre" value=<?php echo $_SESSION['nombre'];?>></td>
     </tr>
     <tr>
       <td>Apellido:</td>
       <td>
         <input type="text" name="apellido" id="documento2" required="required" placeholder="Escriba el Apellido" value=<?php echo $_SESSION["apellido"];?>></td>
     </tr>
     <tr>
       <td><label>Tipo de Documento:</label></td>
       <td><select>
              <option value="">Seleccione..</option>
               <option value="Cedula" <?php if($_SESSION['tipodocumento']=="Cedula"){?>selected="true"<?php } ?> >Cedula</option>
               <option value="Tarjeta de Identidad" <?php if($_SESSION['tipodocumento']=="Tarjeta de Identidad"){?>selected="true"<?php } ?>>Tarjeta de Identidad</option>
           </select></td>
     </tr>
     <tr>
       <td><label>Documento:</label></td>
       <td><label for="documento3"></label>
         <input type="text" name="documento" id="documento3" required="required" placeholder="Escriba el Documento" value=<?php echo $_SESSION["documento"];?>></td>
     </tr>
     
        <tr>
       <td><label>Sexo:</label></td>
          <td><select>
                <option value="">Seleccione..</option>
               <option value="M" <?php if($_SESSION['sexo']=="M"){?>selected="true"<?php } ?> >M</option>
               <option value="F" <?php if($_SESSION['sexo']=="F"){?>selected="true"<?php } ?>>F</option>
           </select>
        </td>
     </tr>
     <tr>
       <td><label>Tipo de Usuario:</label></td>
       <td>
         <select name="user" id="user">
           <option>Seleccione..</option>
           <?php 
           $consulta="select * from rol";
           $resultado=  mysql_query($consulta,$cn);
           while($doc=  mysql_fetch_array($resultado)){
               if($doc['id_rol']==$_SESSION['tipouser']){
                   echo "<option value=".$doc[id_rol]." selected>".$doc['nombre']."</option>";
               }else{
                   echo "<option value=".$doc[id_rol].">".$doc['nombre']."</option>";
               }
           }
           ?>
         </select>
       </td>
     </tr>
     <tr>
       <td><label>Estado:</label></td>
       <td>
           <select name="estado">
               <option value="">Seleccione..</option>
               <option value="Activo" <?php if($_SESSION['estado']=="Activo"){?>selected="true"<?php } ?> >Activo</option>
               <option value="Inactivo" <?php if($_SESSION['estado']=="Inactivo"){?>selected="true"<?php } ?>>Inactivo</option>
           </select>
        </td>
     </tr>
    
</table>
    <input type="submit" value="enviar" />
</form>