<?php
session_start();
$conexion =mysql_connect("localhost","root","")or die("Error en la conexion ");
$db=mysql_select_db("registro")or die("Error en la Base de datos");

$nombre;
$apellido;
$documento;
$contraseña;
$sexo;
$tipouser;
$estado;


$consultperfil ="select * from usuario u,rol r where u.documento='".$_SESSION['documentologin']."' and u.tipo_usuario= r.id_rol";
$resultado = mysql_query($consultperfil,$conexion);
while ($algo=  mysql_fetch_array($resultado))
{
$nombre =$algo['nombre_usuario'];
$apellido=$algo['apellido'];
$documento=$algo['documento'];
$contraseña=$algo['contrasena'];
$sexo=$algo['sexo'];
$tipouser=$algo['nombre'];
$estado=$algo['estado'];   
}
?>





 


<form action="" method="POST" id="registro">
    
    
    <table border="0" width="20" cellspacing="20" style="margin-left:30%;">
        
        <thead>
            <tr>
                
                <div class="textoTitle">Mi Perfil</div>
                <th><label>Nombre:</label></th>
                <th><input type="text" name="nombre" id="nombre"  readonly="readonly"value=<?php echo $nombre?> > </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><label>Apellido</label></td>
                <td><input type="text" name="apellido" id="apellido" readonly="readonly" value=<?php echo $apellido   ?> ></td>
            </tr>
           
            <tr>
                <td><label>Documento:</label></td>
                <td><input type="text" name="documento" id="documento" readonly="readonly" value=<?php  echo $documento ?> > </td>
            </tr>
            <tr>
                <td><label>Sexo:</label></td>
                <td><input type="text" name="sexo" id="sexo" readonly="readonly" value=<?php  echo$sexo ?>></td>
            </tr>
            <tr>
                <td><label>Tipo de Usuario:</label></td>
                <td><input type="text" name="usuario" id="usuario" readonly="readonly" value=<?php  echo $tipouser?>  ></td>
            </tr>
            <tr>
                <td><label>Estado:</label></td>
                <td><input type="text" name="estado" id="estado" readonly="readonly" value=<?php   echo $estado?>></td>
            </tr>
            
        </tbody>
    </table>

    <input type="submit" value="Guardar" />
    <input type="submit" value="Volver">
    
    </form>
    
    
    
    
<form  action="datos/actualizacontrasena.php" method="POST">

    <table border="0" width="20" cellspacing="20" style="margin-left:30%;">
        <thead>
            <tr>
                <th><label>Actual Contraseña:</label></th>
                <th><input type="password" name="contrasena" id="contasena"></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><label>Nueva Contraseña</label></td>
                <td><input type="password" name="nuevacontrasena" id="nuevacontrasena"></td>
            </tr>
            <tr>
                <td><label> Confirme Contraseña</label></td>
                <td><input type="password" name="confirmecontrasena" id="confirmecontrasena"></td>
            </tr>
            
        </tbody>
    </table>

    
    <input type="submit" value="Actualizar">
    
    </form>
    
    
    
    


