-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-06-2016 a las 15:22:58
-- Versión del servidor: 10.1.9-MariaDB
-- Versión de PHP: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `registro`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencia`
--

CREATE TABLE `asistencia` (
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `asistencia` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `salon` varchar(15) NOT NULL,
  `materia` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistencia`
--

INSERT INTO `asistencia` (`nombre`, `apellido`, `asistencia`, `fecha`, `hora`, `salon`, `materia`, `descripcion`) VALUES
('carlos ivan', 'paez', 'Asistio', '2015-02-04', '10:20:59', '105', 'matematicas discretas', 'Asisitio a la clase sin novedad'),
('Carlos', 'santos', 'Asistio', '2015-03-02', '06:00:00', '107', 'java', 'fwaefwef'),
('Julian', 'Barrera', 'Asistio', '2015-03-02', '08:58:00', '109', 'php', 'Materia relacionada  a la web');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente`
--

CREATE TABLE `docente` (
  `nombre` varchar(20) DEFAULT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `cedula` int(15) NOT NULL DEFAULT '0',
  `sexo` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

CREATE TABLE `modulo` (
  `idmodulo` int(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `modulo`
--

INSERT INTO `modulo` (`idmodulo`, `nombre`, `descripcion`) VALUES
(1, 'Roles', 'Creación asignación y poder editar los diferentes '),
(2, 'Usuarios', 'Poder modificar los usuarios según sus utilidades '),
(3, 'salones', 'Permitir modificar registrar eliminar salones y pr'),
(4, 'Asistencia', 'Poder registrar modificar la asistencia de los doc'),
(5, 'Reportes', 'Generar reportes por fecha');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegio`
--

CREATE TABLE `privilegio` (
  `idprivilegio` int(11) NOT NULL,
  `modulo` int(11) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `privilegio`
--

INSERT INTO `privilegio` (`idprivilegio`, `modulo`, `descripcion`) VALUES
(1, 1, 'Registrar un rol'),
(2, 1, 'eliminar un rol'),
(3, 1, 'Editar un rol'),
(4, 1, 'Consultar un rol'),
(5, 2, 'Ingresar un usuario'),
(6, 2, 'Editar un usuario'),
(7, 2, 'Eliminar un usuario'),
(8, 2, 'Consultar un usuario'),
(9, 3, 'Ingresar salones '),
(10, 3, 'editar salones'),
(11, 3, 'Consultar salones'),
(12, 4, 'Ingresar asistencia'),
(13, 4, 'Editar asistencia'),
(15, 4, 'Consultar asistencia'),
(16, 5, 'Generar reportes entre fechas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegiousuario`
--

CREATE TABLE `privilegiousuario` (
  `usuario` int(11) NOT NULL,
  `rol` int(11) NOT NULL,
  `modulo` int(11) NOT NULL,
  `privilegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `privilegiousuario`
--

INSERT INTO `privilegiousuario` (`usuario`, `rol`, `modulo`, `privilegio`) VALUES
(1, 1, 1, 1),
(1, 1, 1, 2),
(1, 1, 1, 3),
(1, 1, 1, 4),
(1, 1, 2, 5),
(1, 1, 2, 6),
(1, 1, 2, 7),
(1, 1, 2, 8),
(1, 1, 3, 9),
(1, 1, 3, 10),
(1, 1, 3, 11),
(1, 1, 4, 12),
(1, 1, 4, 13),
(1, 1, 4, 14),
(1, 1, 4, 15),
(1, 1, 5, 16),
(1, 1, 2, 17),
(1, 1, 2, 18),
(1, 1, 2, 19),
(1, 1, 2, 20),
(0, 2, 2, 8),
(0, 2, 4, 12),
(0, 2, 4, 15),
(0, 2, 2, 17),
(0, 2, 2, 17);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int(100) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre`, `descripcion`) VALUES
(1, 'administrador', 'Tiene todos los privilegios'),
(2, 'Tecnico', 'Es el que toma la asistencia docente'),
(3, 'Administrativo', 'Es el encargado de ver los reportes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rolprivilegio`
--

CREATE TABLE `rolprivilegio` (
  `rol` int(20) NOT NULL,
  `modulo` int(20) NOT NULL,
  `privilegio` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `rolprivilegio`
--

INSERT INTO `rolprivilegio` (`rol`, `modulo`, `privilegio`) VALUES
(1, 1, 1),
(1, 1, 2),
(1, 1, 3),
(1, 1, 4),
(1, 2, 5),
(1, 2, 6),
(1, 2, 7),
(1, 2, 8),
(1, 3, 9),
(1, 3, 10),
(1, 3, 11),
(1, 4, 12),
(1, 4, 13),
(1, 4, 14),
(1, 4, 15),
(1, 5, 16),
(1, 2, 17),
(1, 2, 18),
(1, 2, 19),
(1, 2, 20),
(2, 2, 5),
(2, 2, 8),
(2, 3, 11),
(2, 4, 12),
(2, 4, 15),
(2, 2, 17),
(2, 2, 18),
(2, 2, 19),
(3, 5, 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salon`
--

CREATE TABLE `salon` (
  `id_salon` int(100) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `descripcion` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `salon`
--

INSERT INTO `salon` (`id_salon`, `nombre`, `descripcion`) VALUES
(2, '105', 'Facultad de derecho'),
(3, '106', 'facultad de derecho'),
(4, '107', 'facultad de derecho'),
(5, '108', 'facultad de derecho'),
(6, '109', 'facultad de derecho'),
(7, '110', 'facultad de derecho'),
(8, '111', 'facultad de derecho'),
(9, '112', 'facutad de derecho'),
(10, '115', 'Isla'),
(11, '116', 'Isla'),
(12, '117', 'Isla'),
(13, '118', 'Isla'),
(14, '201', 'Contaduria'),
(15, '202', 'Contaduria'),
(16, '203', 'Contaduria'),
(17, '204', 'Contaduria'),
(18, '205', 'Contaduria'),
(19, '206', 'Contaduria'),
(20, '207', 'Contaduria'),
(21, '208', 'Contaduria'),
(22, '209', 'Contaduria'),
(23, '210', 'Contaduria'),
(24, '215', 'Ingenieria'),
(25, '216', 'Ingenieria'),
(26, '217', 'Ingenieria'),
(27, '218', 'Ingenieria'),
(28, '219', 'Ingenieria'),
(29, '220', 'Ingenieria'),
(30, '221', 'Ingenieria'),
(31, '5201', 'Postgrados');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(20) NOT NULL,
  `nombre_usuario` varchar(30) DEFAULT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `tipo_documento` varchar(30) DEFAULT NULL,
  `documento` varchar(30) NOT NULL DEFAULT '',
  `contrasena` varchar(20) DEFAULT NULL,
  `sexo` varchar(30) DEFAULT NULL,
  `tipo_usuario` varchar(30) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre_usuario`, `apellido`, `tipo_documento`, `documento`, `contrasena`, `sexo`, `tipo_usuario`, `estado`) VALUES
(1, 'andres', 'perez', 'Cedula', '1090391035', '231234', 'M', '1', 'Activo'),
(3, 'Freddy', 'Arango', 'Cedula', '27534123', '231234', 'M', '3', 'Activo'),
(2, 'Carlos', 'Pereira', 'Cedula', '60294212', '123456', 'M', '2', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `docente`
--
ALTER TABLE `docente`
  ADD PRIMARY KEY (`cedula`);

--
-- Indices de la tabla `modulo`
--
ALTER TABLE `modulo`
  ADD PRIMARY KEY (`idmodulo`);

--
-- Indices de la tabla `privilegio`
--
ALTER TABLE `privilegio`
  ADD PRIMARY KEY (`idprivilegio`),
  ADD KEY `modulo` (`modulo`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `salon`
--
ALTER TABLE `salon`
  ADD PRIMARY KEY (`id_salon`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`documento`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `modulo`
--
ALTER TABLE `modulo`
  MODIFY `idmodulo` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `privilegio`
--
ALTER TABLE `privilegio`
  MODIFY `idprivilegio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id_rol` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `salon`
--
ALTER TABLE `salon`
  MODIFY `id_salon` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
